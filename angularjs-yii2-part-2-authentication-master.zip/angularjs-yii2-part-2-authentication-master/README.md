AngularJS and Yii2 Part 2: Authentication
================================

If you're planning on running these on your server don't forget to:
~~~
php composer.phar install
~~~
and initialize the environment
~~~
php init
~~~

The tutorial is located here [Neat Tutorials](http://blog.neattutorials.com/angularjs-and-yii2-part-2-authentication/)
